import React from 'react';
interface Props {
    token?: string | null;
    environment?: string | null;
    onSuccess?: (data: object) => void;
    onFailed?: (error: object) => void;
    onCancel?: (data: object) => void;
}
declare const GQTokenCheckout: React.FC<Props>;
export default GQTokenCheckout;
//# sourceMappingURL=GQTokenCheckout.d.ts.map