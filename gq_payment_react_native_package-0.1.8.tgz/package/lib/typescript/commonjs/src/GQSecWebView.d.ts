import React from 'react';
interface GQSecWebViewProps {
    url: string;
    onClose: () => void;
}
declare const GQSecWebView: React.FC<GQSecWebViewProps>;
export default GQSecWebView;
//# sourceMappingURL=GQSecWebView.d.ts.map