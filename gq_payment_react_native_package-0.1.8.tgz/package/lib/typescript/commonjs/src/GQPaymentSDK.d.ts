import React from 'react';
interface config {
    auth: {
        client_id: string;
        client_secret_key: string;
        gq_api_key: string;
    };
    student_id: string;
    env: string;
    customer_number: string;
    reference_id: string;
    emi_plan_id: string;
    udf_details: object;
    pp_config: {
        slug: string;
    };
    payment_methods: string;
    fee_headers: object;
    fee_headers_split: object;
    customization: {
        theme_color: string;
    };
}
interface prefill {
}
interface Props {
    config?: config | null;
    prefill?: prefill | null;
    onSuccess?: (data: object) => void;
    onFailed?: (error: object) => void;
    onCancel?: (data: object) => void;
}
declare const GQPaymentSDK: React.FC<Props>;
export default GQPaymentSDK;
//# sourceMappingURL=GQPaymentSDK.d.ts.map