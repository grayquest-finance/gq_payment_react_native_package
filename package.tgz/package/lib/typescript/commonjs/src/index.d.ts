import React from 'react';
interface ClientObject {
    auth: {
        client_id: string;
        client_secret_key: string;
        gq_api_key: string;
    };
    student_id: string;
    env: string;
    customer_number: string;
    pp_config: {
        slug: string;
    };
    fee_headers: object;
    customization: {
        theme_color: string;
    };
}
interface PrefillObject {
}
interface Props {
    clientObject?: ClientObject | null;
    prefillObject?: PrefillObject | null;
    onSuccess?: (data: object) => void;
    onFailed?: (error: object) => void;
    onCancel?: (data: object) => void;
}
declare const GQPaymentSDK: React.FC<Props>;
export default GQPaymentSDK;
//# sourceMappingURL=index.d.ts.map