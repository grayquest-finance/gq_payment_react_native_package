import React from 'react';
interface GQWebViewProps {
    url: string;
    sdkSuccess: (data: any) => void;
    sdkCancel: (data: any) => void;
    sdkError: (data: any) => void;
}
declare const GQWebView: React.FC<GQWebViewProps>;
export default GQWebView;
//# sourceMappingURL=GQWebView.d.ts.map