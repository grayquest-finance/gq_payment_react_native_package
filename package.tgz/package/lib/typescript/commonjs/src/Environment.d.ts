export declare const Environment: {
    CREATE_CUSTOMER_API: string;
    VERSION: string;
    setEnvironment(env: any): any;
    getEnvironment(): string;
    getbaseURL(): string;
    gteWebBaseURL(): string;
    getCashfreeEnv(): any;
};
//# sourceMappingURL=Environment.d.ts.map