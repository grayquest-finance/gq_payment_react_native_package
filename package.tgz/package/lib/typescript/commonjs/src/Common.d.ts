export declare const Common: {
    isValidJson(jsonString: string): boolean;
    isValidAuth(jsonString: string): {
        isValid: boolean;
        message: any;
    };
    isValidPPConfig(jsonString: string): {
        isValid: boolean;
        message: any;
    };
    isValidCustomization(jsonString: string): {
        isValid: boolean;
        message: any;
    };
    isValidEnv(env: any): boolean;
    isValidString(value: any): boolean;
    isValidMobileNumber(mobile: any): boolean;
    encodeBase64(str: any): string;
    makeApiCall(number: any, client_id: any, client_secret_key: any, gq_api_key: any): Promise<any>;
};
//# sourceMappingURL=Common.d.ts.map